https://github.com/StRaWsYss/strawsystester
1- open steam
2- launch loader
3-insert the key-

(your key must be unique)

3-click the injection
4- that's it, your HardWare ID will be processed for 24 hours, after which you can safely play. Such problems can be observed if the cheat is in Beta Test