local Cfg = fatality.config;
local Ui = fatality.menu;
local Callback = fatality.callbacks;

local cvar = csgo.interface_handler:get_cvar();
local var_aspectratio = cvar:find_var("r_aspectratio");

local AspectRatioCfg = Cfg:add_item("AspectRatioValue", 0.0);
local AspectRatioValue = Ui:add_slider("AspectRatio", "Visuals", "Misc", "Local", AspectRatioCfg, 0.0, 5.0, 0.1);

local function AspectRatioFunc()
    if var_aspectratio:get_float() ~= AspectRatioCfg:get_float() then
        var_aspectratio:set_float(AspectRatioCfg:get_float())
    end
end

Callback:add("paint", AspectRatioFunc);