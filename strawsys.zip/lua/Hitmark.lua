local menu = fatality.menu
 
-- config
local config = fatality.config
 
-- render
local render = fatality.render
 
-- global vars
local global_vars = csgo.interface_handler:get_global_vars( )
 
-- entity list
local entity_list = csgo.interface_handler:get_entity_list( )
 
 
-- engine client
local engine_client = csgo.interface_handler:get_engine_client( )
 
 
 
-- [ MENU FUNCTIONS ] --
 
    -- hitlog enabled
    local hitlog_item = config:add_item( "hitlog_item", 0 )
    local hitlog_checkbox = menu:add_checkbox( "Hitlogs", "visuals", "Misc", "Beams", hitlog_item )
 
    -- colour picker
    local colour_item = config:add_item("colour_item", 0)
    local colour_slider = menu:add_slider("Hitlogs colour", "visuals", "Misc", "Beams", colour_item, 0 , 9, 1)
 
    -- background enabled
    local background_item = config:add_item( "background_item", 0 )
    local background_checkbox = menu:add_checkbox( "Background", "visuals", "esp", "world", background_item )
 
 
    -- animation type
    local animSide_item  = config:add_item("animSide_item", 0)
    local animSide_combo = menu:add_combo("Animation side", "visuals", "esp", "world", animSide_item)
    animSide_combo:add_item("- Default", animSide_item)
    animSide_combo:add_item("< Left", animSide_item)
    animSide_combo:add_item("> Right", animSide_item)
    animSide_combo:add_item("v Bottom", animSide_item)
 
    -- animation speed
    local animSpeed_item = config:add_item("animSpeed_item", 30)
    local animSpeed_slider = menu:add_slider("Animation speed", "visuals", "esp", "world", animSpeed_item, 25 , 150, 1)
 
    -- font switcher
    local font_item  = config:add_item("font_item", 0)
    local font_combo = menu:add_combo("Fonts", "visuals", "esp", "world", font_item)
    font_combo:add_item("Courier New", font_item)
    font_combo:add_item("Verdana", font_item)
    font_combo:add_item("Verdana Bold", font_item)
 
    -- outlined font
    local outlined_item = config:add_item( "outlined_item", 0 )
    local outlined_checkbox = menu:add_checkbox( "Outlined font", "visuals", "esp", "world", outlined_item )
 
    -- show hitboxes
    local hitbox_item = config:add_item( "hitbox_item", 0 )
    local hitbox_checkbox = menu:add_checkbox( "Show hitboxes", "visuals", "esp", "world", hitbox_item )
 
    -- hitbox type
    local hitboxType_item = config:add_item("hitboxType_item", 0)
    local hitboxType_combo = menu:add_combo("Hitbox type", "visuals", "esp", "world", hitboxType_item)
    hitboxType_combo:add_item("Only hitted part", hitboxType_item)
    hitboxType_combo:add_item("Full hitbox", hitboxType_item)
 
    -- colour picker
    local hitboxesCol_item = config:add_item("hitboxesCol_item", 0)
    local hitboxesCol_slider = menu:add_slider("Hitbox colour", "visuals", "esp", "world", hitboxesCol_item, 0 , 9, 1)
 
-- [ MENU FUNCTIONS ] --  
 
 
 
-- [ FONTS ] --
 
    -- outlined
    local courier14_outl = render:create_font( "Courier new", 14, 400, true );
    local verdana12_outl = render:create_font( "Verdana", 12, 400, true );
    local verdanaBold12_outl = render:create_font( "Verdana Bold", 12, 600, true );
 
    -- without otline
    local courier14 = render:create_font( "Courier new", 14, 400, false );
    local verdana12 = render:create_font( "Verdana", 12, 400, false );
    local verdanaBold12 = render:create_font( "Verdana Bold", 12, 600, false );
 
-- [ FONTS ] --
 
 
 
-- adding logs to this variable
local logs = { }
 
-- getting personal screen size
local screensize = render:screen_size( )
 
 
 
-- on paint function
function on_paint( )
 
    -- in-game check
    if(not engine_client:is_in_game()) then
        return
    end
   
    -- counting logs
    for c = 1, #logs do
           
        -- nil check
        if(logs[ c ] == nil) then
            return
        end
               
        -- rewriting positions from world to screen
        local pos = csgo.vector3(logs[ c ].pos.x, logs[ c ].pos.y, logs[ c ].pos.z)
           
        -- rewriting value from float to int
        local animSpeed_value = animSpeed_item:get_float( ) * 1
        local colour_value = colour_item:get_float( ) * 1
           
        -- animated opacity
        local opacity = math.floor(255 * (global_vars.realtime - logs[ c ].rTime) / 2)
 
        if(global_vars.realtime - logs[ c ].rTime > 2.0) then
            opacity = math.floor(255 - 255 * (global_vars.realtime - logs[ c ].rTime) / 2)
        end
 
            -- customizable animations
            if animSide_item:get_int( ) == 0 then
                logs[ c ].pos.z = logs[ c ].pos.z + ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            elseif animSide_item:get_int( ) == 1 then
                logs[ c ].pos.x = logs[ c ].pos.x - ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            elseif animSide_item:get_int( ) == 2 then
                logs[ c ].pos.x = logs[ c ].pos.x + ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            elseif animSide_item:get_int( ) == 3 then
                logs[ c ].pos.z = logs[ c ].pos.z - ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            end
            logs[ c ].fTime = global_vars.realtime
 
            -- colour changer
            if colour_value == 0 then
                colour_picker = csgo.color(255, 0, 0, opacity) --< red
                elseif colour_value == 1 then
                colour_picker = csgo.color(255, 144, 0, opacity) --< orange
                elseif colour_value == 2 then
                colour_picker = csgo.color(118, 255, 0, opacity) --< green
                elseif colour_value == 3 then
                colour_picker = csgo.color(0, 255, 135, opacity) --< light-green
                elseif colour_value == 4 then
                colour_picker = csgo.color(0, 221, 255, opacity) --< blue
                elseif colour_value == 5 then
                colour_picker = csgo.color(0, 97, 255, opacity) --< dark-blue
                elseif colour_value == 6 then
                colour_picker = csgo.color(102, 0, 255, opacity) --< purple
                elseif colour_value == 7 then
                colour_picker = csgo.color(170, 0, 255, opacity) --< light-purple
                elseif colour_value == 8 then
                colour_picker = csgo.color(255, 0, 152, opacity) --< pink
                elseif colour_value == 9 then
                colour_picker = csgo.color(255, 255, 255, opacity) --< white
                else
                colour_picker = csgo.color(255, 255, 255, opacity) --< default
            end
       
            -- screen check
            if(pos:to_screen( )) then
               
                -- if hitlogs were activated
                if hitlog_item:get_bool( ) then
 
                    -- if backgoround was activated
                    if background_item:get_bool( ) then
 
                        -- if damage lenght > 3 symbols
                        if logs[ c ].dmg >= 100 then
                            render:rect(pos.x - 10, pos.y - 9, 35, 15, colour_picker)
                            render:rect_filled(pos.x - 10, pos.y - 9, 35, 15, csgo.color(0, 0, 0, 150))
                        else
                            render:rect(pos.x - 10, pos.y - 9, 28, 15, colour_picker)
                            render:rect_filled(pos.x - 10, pos.y - 9, 28, 15, csgo.color(0, 0, 0, 150))
                        end
 
                    end
 
                    -- if outlined text was activated
                    if outlined_item:get_bool( ) then
 
                        -- swithcing fonts
                        if font_item:get_int( ) == 0 then
                            render:text(courier14_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 1 then
                            render:text(verdana12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 2 then
                            render:text(verdanaBold12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        end
 
                    -- fonts without online
                    else
 
                         -- swithcing fonts
                        if font_item:get_int( ) == 0 then
                            render:text(courier14, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 1 then
                            render:text(verdana12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 2 then
                            render:text(verdanaBold12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        end
 
                    end
 
                end
           
            if(global_vars.realtime - logs[ c ].rTime > 4.0) then
                table.remove(logs, c)
            end
 
        end
 
    end
   
end
 
 
 
-- on shot function
function on_shot( shot )
 
    -- in-game check
    if(not engine_client:is_in_game()) then
        return
    end
 
    -- getting hitted player
    player = entity_list:get_player( shot.victim )
 
    -- player check
    if player == nil then
    return end
 
    local hitBoxesColour_value = hitboxesCol_item:get_float( ) * 1
 
    if hitBoxesColour_value == 0 then
        box_col = csgo.color(255, 0, 0, 25) --< red
        elseif hitBoxesColour_value == 1 then
            box_col = csgo.color(255, 144, 0, 25) --< orange
        elseif hitBoxesColour_value == 2 then
            box_col = csgo.color(118, 255, 0, 25) --< green
        elseif hitBoxesColour_value == 3 then
            box_col = csgo.color(0, 255, 135, 25) --< light-green
        elseif hitBoxesColour_value == 4 then
            box_col = csgo.color(0, 221, 255, 25) --< blue
        elseif hitBoxesColour_value == 5 then
            box_col = csgo.color(0, 97, 255, 25) --< dark-blue
        elseif hitBoxesColour_value == 6 then
            box_col = csgo.color(102, 0, 255, 25) --< purple
        elseif hitBoxesColour_value == 7 then
            box_col = csgo.color(170, 0, 255, 25) --< light-purple
        elseif hitBoxesColour_value == 8 then
            box_col = csgo.color(255, 0, 152, 25) --< pink
        elseif hitBoxesColour_value == 9 then
            box_col = csgo.color(255, 255, 255, 25) --< white
        else
            box_col = csgo.color(255, 255, 255, 25) --< default
    end
     
    -- hit
    if shot.hurt then
 
        table.insert(logs, {pos = csgo.vector3(shot.hitpos.x, shot.hitpos.y, shot.hitpos.z), fTime = global_vars.realtime, rTime = global_vars.realtime, dmg = shot.hit_damage, hitgroup = shot.hit_hitgroup})
 
        if hitbox_item:get_bool( ) then
 
            if hitboxType_item:get_int( ) == 0 then
                render:draw_hitgroup( player, shot.record.matrix, shot.hit_hitgroup, 3.0, box_col )
                render:draw_hitgroup( player, shot.record.matrix, -1, 3.0, csgo.color(255, 0, 0, 2) )
            elseif hitboxType_item:get_int( ) == 1 then
                render:draw_hitgroup( player, shot.record.matrix, -1, 3.0, box_col )
            end
 
        end
    end
 
end
 
 
 
-- callbacks
 
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)
 
-- end of the code