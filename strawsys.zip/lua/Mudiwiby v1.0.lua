-- interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local onetap_keybind = config:add_item( "vis_keybinds", 0 )
local onetap_speclist_speclist_checkbox = menu:add_checkbox( "Keybinds indicator", "visuals", "misc", "various", onetap_keybind )
local onetap_keybinds_item = config:add_item("vis_keybindscol", 0)
local onetap_bar_combobox1 = menu:add_combo( "rainbow mode", "visuals", "misc", "various", onetap_keybinds_item):add_item( "rainbow", onetap_keybinds_item):add_item( "gradient rainbow", onetap_keybinds_item)
local screensize = render:screen_size();
local x_value_item = config:add_item("xvalue_keybinds", 0)
local x_slider = menu:add_slider("x slider", "visuals", "misc", "various", x_value_item, 0 , screensize.x, 1)
local dt1 = menu:get_reference("rage", "weapons", "auto", "double tap")
local dt2 = menu:get_reference("rage", "weapons", "Pistols", "double tap")
local dt3 = menu:get_reference("rage", "weapons", "Other", "double tap")
local dt4 = menu:get_reference("rage", "weapons", "Heavy Pistols", "double tap")

local fallback = menu:get_reference("rage", "aimbot","aimbot", "Force Fallback")

local silent1 = menu:get_reference("rage", "weapons", "auto", "silent")
local silent2 = menu:get_reference("rage", "weapons", "awp", "silent")
local silent3 = menu:get_reference("rage", "weapons", "Pistols", "silent")
local silent4 = menu:get_reference("rage", "weapons", "Other", "silent")
local silent5 = menu:get_reference("rage", "weapons", "Heavy Pistols", "silent")
local silent6 = menu:get_reference("rage", "weapons", "Scout", "silent")

local aa_right = menu:get_reference( "rage", "anti-aim", "general", "right" )
local aa_left = menu:get_reference( "rage", "anti-aim", "general", "left" )
local aa_back = menu:get_reference( "rage", "anti-aim", "general", "back" )

local fakeduck = menu:get_reference("misc", "", "Movement", "Fake duck")
print( "OT keybinds indicator lua is loaded. by anti#2528 (Zel9)")
local y_value_item = config:add_item("yvalue_keybinds", 0)
local y_slider = menu:add_slider("y slider", "visuals", "misc", "various", y_value_item, 0, screensize.y, 1 )
local tahoma = render:create_font( "Tahoma", 13, 500, true );
function draw_container_onetap( x, y, w, h, title )
    local c = {10, 60, 40, 40, 40, 60, 20};
    
    render:rect_filled(x + 10, y + 6, 180, 20, csgo.color(0,0,0,50))
    render:text(tahoma, x + w / 3, y + 9, title, csgo.color(255,255,255,230))
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
    local r1 = math.floor( math.sin( global_vars.realtime * 2.3) * 127 + 128 );
    local g1 =  math.floor( math.sin( global_vars.realtime * 2.3 + 2 ) * 127 + 128 );
    local b1 = math.floor( math.sin( global_vars.realtime * 2.3 + 4 ) * 127 + 128 );
    if onetap_keybinds_item:get_int() == 1 then
        render:rect_fade( x + 10, y + 2, 180, 5, csgo.color(r,g,b,250), csgo.color(r1, g1, b1, 250), true );
        render:rect( x + 10, y + 2, 180, 5, csgo.color( 0, 0, 0, 250 ) );
    elseif onetap_keybinds_item:get_int() == 0 then
        render:rect_filled( x + 10, y + 2, 180, 5, csgo.color( r,g,b, 250 ) );
        render:rect( x + 10, y + 2, 180, 5, csgo.color( 0, 0, 0, 250 ) );
    end
end




function on_paint()
    if not engine_client:is_in_game( ) then
    return end
    local local_player = entity_list:get_localplayer()
    local getslidervalue_x = x_value_item:get_float() * 1
    local getslidervalue_y = y_value_item:get_float() * 1
    local spec_list_pos = csgo.vector2( getslidervalue_x, getslidervalue_y )
    if(local_player:is_alive())then
        local weapon_handle = local_player:get_var_handle("CBaseCombatCharacter->m_hActiveWeapon")
    local weapon_entity = entity_list:get_from_handle(weapon_handle)
    if(weapon_entity ~= nil)then

local yPOS;
if(dt)then
    yPOS = spec_list_pos.y + 45
else
    yPOS = spec_list_pos.y + 30
end
local yPOS1;
if(silent and dt)then
    yPOS1 = spec_list_pos.y + 60
elseif(dt)then
    yPOS1 = spec_list_pos.y + 45
elseif(silent)then
    yPOS1 = spec_list_pos.y + 45
elseif(fakeduck:get_bool())then
    yPOS1 = spec_list_pos.y + 45
else
    yPOS1 = spec_list_pos.y + 30
end


    if(onetap_keybind:get_bool())then
          draw_container_onetap(spec_list_pos.x, spec_list_pos.y, 200, 1 * 16 + 45, "    keybinds")

          if(fakeduck:get_bool())then
        
             render:text(tahoma, spec_list_pos.x + 16, spec_list_pos.y + 30, "[toggled] fakeduck", csgo.color(255,255,255,250))
          end
          if(fallback:get_bool())then
             render:text(tahoma, spec_list_pos.x + 16, yPOS1, "[toggled] force fallback", csgo.color(255,255,255,250))
          end
          if (dt1:get_int() ~= 0 and (weapon_entity:get_class_id() == 260 or weapon_entity:get_class_id() == 241) or (dt2:get_int() ~= 0 and (weapon_entity:get_class_id() == 238 or weapon_entity:get_class_id() == 244 or weapon_entity:get_class_id() == 271)) or (dt4:get_int() ~= 0 and (weapon_entity:get_class_id() == 64 or weapon_entity:get_class_id() == 46)))then
            if(fakeduck:get_bool())then
                dt = false;
                return
            end
            dt = true;
          render:text(tahoma, spec_list_pos.x + 16, spec_list_pos.y + 30, "[toggled] double-tap", csgo.color(255,255,255,250))
          else
            dt = false
          end

          if((silent1:get_bool() and (weapon_entity:get_class_id() == 260 or weapon_entity:get_class_id() == 241)) or (silent2:get_bool() and weapon_entity:get_class_id() == 232) or (silent3:get_bool() and (weapon_entity:get_class_id() == 238 or weapon_entity:get_class_id() == 244 or weapon_entity:get_class_id() == 271)) or (silent5:get_bool() and (weapon_entity:get_class_id() == 64 or weapon_entity:get_class_id() == 46)) or (silent6:get_bool() and weapon_entity:get_class_id() == 261))then
            if(fakeduck:get_bool())then
                silent = false;
                return
            end
            silent = true;
            render:text(tahoma, spec_list_pos.x + 16, yPOS, "[toggled] silent", csgo.color(255,255,255,250))
          else
            silent = false;
          end




    end
end
end
end
local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )