

-- if you want to change the key for the legit aa, change it here:

local key_aa = 0x45 -- list of virtual keys here: https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes

local config = fatality.config
local menu = fatality.menu
local callback = fatality.callbacks
local input = fatality.input
local engine_client = csgo.interface_handler:get_engine_client( )

local pitch = menu:get_reference( "Rage", "Anti-Aim", "Angles", "Pitch" )
local yaw = menu:get_reference( "Rage", "Anti-Aim", "Angles", "Yaw" )
local attargets = menu:get_reference( "Rage", "Anti-Aim", "Angles", "At fov target" )

local pitch_backup = pitch:get_int()
local yaw_backup = yaw:get_int()
local attargets_backup = attargets:get_int()

local restore_aa = false


callback:add("paint", function()
    if (input:is_key_down(key_aa)) then -- E KEY
        engine_client:client_cmd_unrestricted( "-use" )
        pitch:set_int(0)
        yaw:set_int(0)
        attargets:set_int(0)
        restore_aa = true
    else
        if (restore_aa == true) then
            pitch:set_int(pitch_backup)
            yaw:set_int(yaw_backup)
            attargets:set_int(attargets_backup)
            restore_aa = false
        else
            pitch_backup = pitch:get_int()
            yaw_backup = yaw:get_int()
            attargets_backup = attargets:get_int()
        end
    end
end)

